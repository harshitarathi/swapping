#!/usr/bin/env python3
""" Initialization for faceswap's lib section """
# Import logger here so our custom loglevels are set for when executing code outside of FS
from . import logger
