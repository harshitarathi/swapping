#!/usr/bin/env python3
""" Base class for Models plugins ALL Models should at least inherit from this class. """

from .model import get_all_sub_models, ModelBase
