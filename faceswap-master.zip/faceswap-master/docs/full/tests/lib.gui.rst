***********
gui package
***********

.. contents:: Contents
   :local:

gui.analysis.event_reader module
********************************
Unittests for the :class:`~lib.gui.analysis.event_reader` module

.. automodule:: tests.lib.gui.analysis.event_reader_test
   :members:
   :undoc-members:
   :show-inheritance: