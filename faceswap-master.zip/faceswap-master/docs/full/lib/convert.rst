convert module
==============

.. automodule:: lib.convert
   :members:
   :undoc-members:
   :show-inheritance:
