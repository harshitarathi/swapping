**********
git module
**********

Handles interfacing with the git executable

.. automodule:: lib.git
   :members:
   :undoc-members:
   :show-inheritance:
