******************
update_deps module
******************

.. automodule:: update_deps
   :members:
   :undoc-members:
   :show-inheritance: