.. faceswap documentation master file, created by
   sphinx-quickstart on Fri Sep 13 11:28:50 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

faceswap.dev Developer Documentation
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   full/modules


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
